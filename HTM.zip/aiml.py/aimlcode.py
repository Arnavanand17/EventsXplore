import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

# Sample event data (you can replace this with your own dataset)
events_data = {
    'EventID': [1, 2, 3, 4, 5],
    'EventName': ['Tech Conference', 'Art Exhibition', 'Music Festival', 'Food Fair', 'Sports Game'],
    'Description': ['Join the latest tech conference', 'Explore amazing art exhibits', 'Enjoy live music performances', 'Delicious food from around the world', 'Exciting sports action'],
    'Category': ['Tech', 'Art', 'Music', 'Food', 'Sports'],
}

student_interests = 'art music'  # Replace this with the student's interests

# Create a DataFrame from the event data
events_df = pd.DataFrame(events_data)

# Create a TF-IDF vectorizer to convert event descriptions into numerical features
tfidf_vectorizer = TfidfVectorizer(stop_words='english')
event_descriptions = events_df['Description'].fillna('')
tfidf_matrix = tfidf_vectorizer.fit_transform(event_descriptions)

# Calculate the cosine similarity between the student's interests and event descriptions
student_profile = tfidf_vectorizer.transform([student_interests])
cosine_similarities = linear_kernel(student_profile, tfidf_matrix)

# Get event recommendations based on similarity scores
event_indices = cosine_similarities.argsort()[0][::-1]
recommended_events = events_df.iloc[event_indices]
recommended_events = recommended_events[recommended_events['EventID'] != event_id]  # Exclude events the student is already attending

# Print the recommended events
print("Recommended Events:")
print(recommended_events[['EventName', 'Description', 'Category']])
